package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView CalcuText;
    private int equationResult = 0;  // Holds the result of the calculation
    private String OpCurrent = "";  // Stores the current operator
    private boolean OpClick = false;  // Track if an operator was clicked
    private String NumCurrent = "";  // Holds the current number being entered

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Numbers
        Button btn0 = findViewById(R.id.btn0);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);
        Button btn8 = findViewById(R.id.btn8);
        Button btn9 = findViewById(R.id.btn9);

        // Symbols
        Button btnAC = findViewById(R.id.btnAC);
        Button btnmulti = findViewById(R.id.btnmulti);
        Button btnplus = findViewById(R.id.btnplus);
        Button btnminus = findViewById(R.id.btnminus);
        Button btnequal = findViewById(R.id.btnequal);

        // Text
        CalcuText = findViewById(R.id.CalcuText);

        btn0.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("0");
            }
        });

        btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                addToEquation("9");
            }
        });
        btnplus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                handleOperatorClick("+");
            }
        });
        btnminus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                handleOperatorClick("-");
            }
        });
        btnmulti.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                handleOperatorClick("x");
            }
        });

        btnAC.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                clearEquation();
            }
        });
        btnequal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                evaluateFirstOpEq();
            }
        });
    }

    private void addToEquation(String num) {
        if (OpClick) {
            NumCurrent = "";
            OpClick = false;
        }
        NumCurrent += num;
        CalcuText.setText(CalcuText.getText().toString() + num);
    }

    private void handleOperatorClick(String operator) {
        if (OpClick) {

            String currentDisplay = CalcuText.getText().toString();

            CalcuText.setText(currentDisplay.substring(0, currentDisplay.length() - 1) + operator);
        } else {

            if (!NumCurrent.isEmpty()) {
                if (!OpCurrent.isEmpty()) {

                    evaluateFirstOpEq();
                } else {

                    equationResult = Integer.parseInt(NumCurrent);
                }
            }

            CalcuText.setText(CalcuText.getText().toString() + operator);

            OpClick = true;
        }

        OpCurrent = operator;
    }

    private void clearEquation() {
        CalcuText.setText("");
        CalcuText.setHint("0");
        equationResult = 0;
        OpCurrent = "";
        NumCurrent = "";
        OpClick = false;
    }

    private void evaluateFirstOpEq() {
        if (!OpCurrent.isEmpty() && !NumCurrent.isEmpty()) {
            int sNumber = Integer.parseInt(NumCurrent);

            switch (OpCurrent) {
                case "+":
                    equationResult += sNumber;
                    break;
                case "-":
                    equationResult -= sNumber;
                    break;
                case "x":
                    equationResult *= sNumber;
                    break;
            }

            CalcuText.setText(String.valueOf(equationResult));
            OpCurrent = "";
        }
    }
}
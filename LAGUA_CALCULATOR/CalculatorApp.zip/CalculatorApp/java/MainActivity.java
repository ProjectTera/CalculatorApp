package com.example.applicationkinemer;

import static java.lang.Integer.parseInt;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    public int result = 0;
    public boolean init = false;
    public int num1;
    public String input = "";
    public String operation = "";

    public Button btn1;
    public Button btn2;
    public Button btn3;
    public Button btn4;
    public Button btn5;
    public Button btn6;
    public Button btn7;
    public Button btn8;
    public Button btn9;
    public Button btnAdd;
    public Button btnSubtract;
    public Button btnMultiply;
    public Button btnClear;
    public Button btnCompute;

    public EditText edtInputNum;
    public TextView tvResult;
    public TextView tvNum1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        btnAdd = findViewById(R.id.btnAdd);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnClear = findViewById(R.id.btnClear);
        btnCompute = findViewById(R.id.btnCompute);

        edtInputNum = findViewById(R.id.edtInputNum);
        tvResult = findViewById(R.id.tvResult);
        tvNum1 = findViewById(R.id.tvNum1);
        Button btn0 = findViewById(R.id.btn0);

        btn0.setOnClickListener(view -> {
            setInputNumber(0);
        });

        btn1.setOnClickListener(view -> {
            setInputNumber(1);
        });

        btn2.setOnClickListener(view -> {
            setInputNumber(2);
        });

        btn3.setOnClickListener(view -> {
            setInputNumber(3);
        });

        btn4.setOnClickListener(view -> {
            setInputNumber(4);
        });

        btn5.setOnClickListener(view -> {
            setInputNumber(5);
        });

        btn6.setOnClickListener(view -> {
            setInputNumber(6);
        });

        btn7.setOnClickListener(view -> {
            setInputNumber(7);
        });

        btn8.setOnClickListener(view -> {
            setInputNumber(8);
        });

        btn9.setOnClickListener(view -> {
            setInputNumber(9);
        });

        btnAdd.setOnClickListener(view -> {
            instantiateOperator("+");
        });

        btnMultiply.setOnClickListener(view -> {
            instantiateOperator("*");
        });

        btnSubtract.setOnClickListener(view -> {
            instantiateOperator("-");
        });

        btnClear.setOnClickListener(view -> {
            num1 = 0;
            result = 0;
            input = "0";
            init = false;

            edtInputNum.setText("");
            TVSetText(tvNum1, "");
            TVSetText(tvResult, "");
        });

        btnCompute.setOnClickListener(view -> {
            input = String.valueOf(edtInputNum.getText());

            if (input.isEmpty() || input.isBlank())
                input = "0";

            compute(operation);
            TVSetText(tvResult, "" + result);
        });

    }

    public void compute(String operation)
    {
        switch (operation)
        {
            case "+":
                result = num1 + parseInt(input);
                break;

            case "-":
                result = num1 - parseInt(input);
                break;

            case "*":
                result = num1 * parseInt(input);
                break;

            default:

                if (init && !operation.isBlank())
                {
                    compute(operation);
                }
                else
                {
                    result = 0;
                }
                break;
        }

        TVSetText(tvNum1, String.valueOf(num1) + " " + operation);
        num1 = result;
        input = "";
        init = true;
    }

    public void setInputNumber(int num)
    {
        input = input.startsWith("0") ? input.substring(1) + num : input.concat(String.valueOf(num));
        edtInputNum.setText(input);
    }

    public void instantiateOperator(String operator)
    {
        if (init)
        {
            num1 = result;
            input = String.valueOf(num1);
        }
        else
        {
            num1 = parseInt(input);
        }

        operation = operator;
        TVSetText(tvNum1, input + " " + operation);
        edtInputNum.setText("");
        input = "";
    }

    public void TVSetText(TextView tv, String text) {
        tv.setText(text);
    }

}
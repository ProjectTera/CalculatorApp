package com.example.calculator_activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    public boolean operatorClicked = false;
    public String operator = "";
    private boolean num1NotEmpty = false;
    private boolean num2NotEmpty = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText edtxtNum1 = findViewById(R.id.edtxtNum1);
        EditText edtxtNum2 = findViewById(R.id.edtxtNum2);
        TextView tvOperator = findViewById(R.id.tvOperator);
        TextView tvResult = findViewById(R.id.tvResult);

        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);
        Button btn8 = findViewById(R.id.btn8);
        Button btn9 = findViewById(R.id.btn9);
        Button btn10 = findViewById(R.id.btn10);

        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnMultiply = findViewById(R.id.btnMultiply);
        Button btnSubtract = findViewById(R.id.btnSubtract);
        Button btnEqual = findViewById(R.id.btnEqual);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnAllClear = findViewById(R.id.btnAllClear);


        View.OnClickListener numberClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button clickedButton = (Button) view;
                String number = clickedButton.getText().toString();

                if (!operatorClicked) {
                    String num1 = edtxtNum1.getText().toString();
                    num1 += number;
                    edtxtNum1.setText(num1);
                } else {
                    String num2 = edtxtNum2.getText().toString();
                    num2 += number;
                    edtxtNum2.setText(num2);
                }
            }
        };

        btn1.setOnClickListener(numberClickListener);
        btn2.setOnClickListener(numberClickListener);
        btn3.setOnClickListener(numberClickListener);
        btn4.setOnClickListener(numberClickListener);
        btn5.setOnClickListener(numberClickListener);
        btn6.setOnClickListener(numberClickListener);
        btn7.setOnClickListener(numberClickListener);
        btn8.setOnClickListener(numberClickListener);
        btn9.setOnClickListener(numberClickListener);
        btn10.setOnClickListener(numberClickListener);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isNum1NotEmpty();
                if (num1NotEmpty){
                    operator = "+";
                    tvOperator.setText("+");
                    operatorClicked = true;
                }
            }
        });

        btnMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isNum1NotEmpty();
                if(num1NotEmpty){
                    operator = "x";
                    tvOperator.setText("x");
                    operatorClicked = true;
                }
            }
        });

        btnSubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isNum1NotEmpty();
                if (num1NotEmpty){
                    operator = "-";
                    tvOperator.setText("-");
                    operatorClicked = true;
                }
            }
        });

        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isNum1NotEmpty();
                isNum2NotEmpty();
                if (num1NotEmpty && num2NotEmpty){
                    String num1 = edtxtNum1.getText().toString();
                    String num2 = edtxtNum2.getText().toString();

                    int number1 = Integer.parseInt(num1);
                    int number2 = Integer.parseInt(num2);

                    if (operator.equals("+")){
                        tvResult.setText((number1 + number2) + " ");
                    }

                    if (operator.equals("x")){
                        tvResult.setText((number1 * number2) + " ");
                    }

                    if (operator.equals("-")){
                        tvResult.setText((number1 - number2) + " ");
                    }
                }
            }
        });



        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!operatorClicked) {
                    String num1 = edtxtNum1.getText().toString();
                    if (!num1.isEmpty()) {
                        num1 = num1.substring(0, num1.length() - 1);
                        edtxtNum1.setText(num1);
                    }
                } else {
                    String num2 = edtxtNum2.getText().toString();
                    if (!num2.isEmpty()) {
                        num2 = num2.substring(0, num2.length() - 1);
                        edtxtNum2.setText(num2);
                    }
                }
            }
        });

        btnAllClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtxtNum1.setText("");
                edtxtNum2.setText("");
                tvOperator.setText("");
                tvResult.setText("");
                operatorClicked = false;
            }
        });

    }

    public void isNum1NotEmpty() {
        EditText edtxtNum1 = findViewById(R.id.edtxtNum1);
        if(edtxtNum1.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(),
                    "Enter an integer in the first field",
                    Toast.LENGTH_SHORT).show();
            num1NotEmpty = false;
        } else {
            num1NotEmpty = true;
        }
    }

    public void isNum2NotEmpty() {
        EditText edtxtNum2 = findViewById(R.id.edtxtNum1);
        if(edtxtNum2.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(),
                    "Enter an integer in the second field",
                    Toast.LENGTH_SHORT).show();
            num2NotEmpty = false;
        } else {
            num2NotEmpty = true;
        }
    }
}
package com.example.calculator;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public int a = 0, b = 0;
    public String operator = "";
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);
        Button btn8 = findViewById(R.id.btn8);
        Button btn9 = findViewById(R.id.btn9);
        Button btnADD = findViewById(R.id.btnADD);
        Button btnMINUS = findViewById(R.id.btnMINUS);
        Button btnMULTIPLY = findViewById(R.id.btnMULTIPLY);
        Button btnEquals = findViewById(R.id.btnEquals);
        Button btnClear = findViewById(R.id.btnClear);
        EditText etcalc = findViewById(R.id.etcalc);

        // Add TextView to display result


        View.OnClickListener numberListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button button = (Button) view;
                String value = button.getText().toString();
                etcalc.append(value); // Append the number to the display
            }
        };

        btn1.setOnClickListener(numberListener);
        btn2.setOnClickListener(numberListener);
        btn3.setOnClickListener(numberListener);
        btn4.setOnClickListener(numberListener);
        btn5.setOnClickListener(numberListener);
        btn6.setOnClickListener(numberListener);
        btn7.setOnClickListener(numberListener);
        btn8.setOnClickListener(numberListener);
        btn9.setOnClickListener(numberListener);

        btnADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Integer.parseInt(etcalc.getText().toString()); // Store the first number
                operator = "ADD";
                etcalc.setText(""); // Clear the input for the second number
            }
        });

        btnMINUS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Integer.parseInt(etcalc.getText().toString());
                operator = "MINUS";
                etcalc.setText("");
            }
        });

        btnMULTIPLY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Integer.parseInt(etcalc.getText().toString());
                operator = "MULTIPLY";
                etcalc.setText("");
            }
        });

        btnEquals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b = Integer.parseInt(etcalc.getText().toString()); // Get the second number
                int result = 0;
                switch (operator) {
                    case "ADD":
                        result = a + b;
                        break;
                    case "MINUS":
                        result = a - b;
                        break;
                    case "MULTIPLY":
                        result = a * b;
                        break;
                }
                etcalc.setText(String.valueOf(result)); // Display the result
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etcalc.setText(""); // Clear everything
                a = 0;
                b = 0;
                operator = "";
            }
        });
    }
}

package com.example.activity1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private int firstNumber = 0;
    private int secondNumber = 0;
    private String operator = "";
    private boolean isOperatorClicked = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.tview_result);

        // Set up buttons and their click listeners
        Button btn_9 = findViewById(R.id.btn_9);
        Button btn_8 = findViewById(R.id.btn_8);
        Button btn_7 = findViewById(R.id.btn_7);
        Button btn_6 = findViewById(R.id.btn_6);
        Button btn_5 = findViewById(R.id.btn_5);
        Button btn_4 = findViewById(R.id.btn_4);
        Button btn_3 = findViewById(R.id.btn_3);
        Button btn_2 = findViewById(R.id.btn_2);
        Button btn_1 = findViewById(R.id.btn_1);
        Button btn_plus = findViewById(R.id.btn_plus);
        Button btn_minus = findViewById(R.id.btn_minus);
        Button btn_multiply = findViewById(R.id.btn_multiply);
        Button btn_equals = findViewById(R.id.btn_equals);
        Button btn_delete = findViewById(R.id.btn_delete);


        btn_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("9");
            }
        });
        btn_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("8");
            }
        });
        btn_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("7");
            }
        });
        btn_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("6");
            }
        });
        btn_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("5");
            }
        });
        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("4");
            }
        });
        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("3");
            }
        });
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("2");
            }
        });
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("1");
            }
        });
        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("+");
            }
        });
        btn_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("-");
            }
        });
        btn_multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("*");
            }
        });

        btn_equals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateResult();
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                deletecharacter();
            }
        });
    }

    //Voids
    private void setOperator(String op) {
        String currentText = textView.getText().toString().trim();
        if (!currentText.isEmpty()) {
            try {
                firstNumber = Integer.parseInt(currentText);
                operator = op;
                isOperatorClicked = true;
                textView.setText("");
            } catch (NumberFormatException e) {
                textView.setText("");
            }
        } else {
            textView.setText("");
        }
    }
    private void deletecharacter(){
        String currentText = textView.getText().toString();
        if (!currentText.isEmpty()) {
            currentText = currentText.substring(0,currentText.length()-1);
            if(currentText.isEmpty()){
                textView.setText("0");
                isOperatorClicked = false;
            } else {
            textView.setText(currentText);
            }
        }
    }
    private void appendNumber(String number) {
        if (isOperatorClicked) {
            textView.setText(number);
            isOperatorClicked = false;
        } else {
            String currentText = textView.getText().toString();
            if (currentText.equals("0")) {
                textView.setText(number);
            } else {
                textView.setText(currentText + number);
            }
        }
    }

    private void calculateResult() {
        String currentText = textView.getText().toString().trim();
        if (!currentText.isEmpty() && !operator.isEmpty()) {
            try {
                secondNumber = Integer.parseInt(currentText);
                int result = 0;
                switch (operator) {
                    case "+":
                        result = (firstNumber + secondNumber);
                        break;
                    case "-":
                        result = (firstNumber - secondNumber);
                        break;
                    case "*":
                        result = (firstNumber * secondNumber);
                        break;
                }
                textView.setText(String.valueOf(result));
                operator = "";
                isOperatorClicked = true;
            } catch (NumberFormatException e) {
                textView.setText("");
            }
        }else{
            textView.setText("");
        }
    }
}
